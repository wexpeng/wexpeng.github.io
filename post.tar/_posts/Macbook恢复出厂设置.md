---
title: Macbook恢复出厂设置
tags:
  - 技术
  - Macbook
categories:
  - 经验
abbrlink: 52584
date: 2018-07-29 14:58:38
updated:
password:
abstract:
address:
---


我也没想到苹果电脑良心，可以直接恢复系统到出厂状态。

在开机的时候同时按住`control++shift+optin+command+r`，会联网打开Apple Rec,直接在里面抹去磁盘，再点击安装就可以在线下载系统安装了，我100M的宽带用了一个半小时。

之后，发现老系统看起来不爽，还是新的好。

开机的时候同时按住`command+r`,会联网打开最新的Apple Rec，抹掉、安装。时间一样。记录一下。

<!--more-->
