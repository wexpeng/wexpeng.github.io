---
title: LateX公式使用手册
tags:
  - 博客相关
  - 数据结构
categories: 经验
abbrlink: 30641
date: 1997-03-08 16:59:00
---

大约能够创建出本科高等数学涵盖的公式

目的是简洁方便的网页上创建优美的数学公式。

### 例子


单层结构：
$$ x=y^2 $$

二元一次方程求根公式：
$$ x = \dfrac{-b \pm \sqrt{b^2 - 4ac}}{2a} $$

复杂一丢丢的：
$$ \lim_{n \to \infty} 
\sum_{k=1}^n \frac{1}{k^2} 
= \frac{\pi^2}{6} $$

<!-- more -->
下面再举个复杂一点积分式子作为例子：
$$ A = \frac{1}{\sqrt{2\pi\sigma}}\int_0^\infty\frac{b_1x+c_1}{b_2x+c_2}\exp\left(-\frac{(x-\mu)^2}{2\sigma^2}\right)dx  $$

手册内容完成以上公式毫无压力……

基础规则
每一个例子都给出了写法，在markdown中应该在前后各输入一个$用于解析，同时对于大共识，可以用`$$`，这会是公式剧中且占多行。

### 指数和下标
可以用^和\_后加相应字符来实现。比如：

$a_{2}$ 写作：a_{2}
$x^{2}$ 写作：a^{2}
$e^{-\alpha t}$ 写作：e^{-\alpha t}
$a^{3}\_{ij}$ 写作：a^{3}\_{ij}
$e^{x^2} \neq {e^x}^2$ 写作：e^{x^2} \neq {e^x}^2 

### 平方根（square root）
输入指令为`\sqrt`,n次方根对应为`\squrt[n]`,根号大小有LateX自动调整，也可用`\surd`仅给出符号，比如：
$\sqrt{x}$写作：\sqrt{x}
$\sqrt{x^{2}+\sqrt{y}}$
$\sqrt[3]{2}$
$\surd{x^{2}+y^{2}}$

### 水平线和水平大括号
命令`\overline`和`\underline`在表达式的上、下画出水平线，比如：
$\overline{m+n}$
$\underline{m+n}$

命令`\overbrace`和`\underbrace`在表达式上、下画出水平大括号，比如：
$\underbrace{a+b+\cdots+z}$

### 向量（Vector）
通常上方有小箭头，这可由`\vec`得到，另外`\overrightarrow`和`\overleftarrow`在定义向量，比如：
$\vec{a}$
$\overrightarrow{AB}$
$\overleftarrow{AB}$

### 分数（fraction）
使用`\frac{分子}{分母}`排版，一般来说1/2这种形式也是可以的
$1\frac{1}{2}$
$\frac{x^2}{y+1}$
$x^{1/2}$
$x^{\frac{1}{2}}$


### 积分运算(integral)
$\int\_{0}^{\frac{\pi}{2}}$

### 求和运算(sum)
$\sum\_{i=1}^{n}$

### 乘积运算
$\prod\_\epsilon$


### 常用数学符号


#### 二元关系符

|符号|代码表现形式|符号|代码表现形式|
|:---:|:---|:---:|:---|
|<|<|>|>|
|=|=|$ \leq $ | \\leq or \\le|
|$ \geq $| \\geq or \\ge|$ \equiv $|\\equiv|
|$ \sim $| \\sim | $ \approx $| \\approx|
|$ \notin $| \\notin |$ \neq $| \\neq or \\ne|

#### 大尺寸运算符
|符号|代码表现形式|符号|代码表现形式|
|:---:|:---|:---:|:---|
|$\sum$|\\sum|$\bigcup$|\\bigcup|
|$\prod$|\\prod|$\coprod$|\\coprod|
|$\int$|\\int|$\oint$|\\oint|

#### 其它常用符号
|符号|代码表现形式|符号|代码表现形式|
|:---:|:---|:---:|:---|
|$\pi$|\\pi|$\surd$|\\surd|
|$\therefore$|\\therefore|$\because$|\\because|
|$\alpha$|\\alpha|$\beta$|\\beta|
|$\gamma$|\\gamma|$\mu$|\\mu|




**再次强调**：所有写法要卸载`$`或者`$$`中间，Markdown解析才会生效
