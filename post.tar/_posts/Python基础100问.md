---
title: Python基础100问
tags:
  - python
categories:
  - 经验
address: 马士兵（北京）教育科技有限公司
abbrlink: da51543a
date: 2022-02-26 00:21:29
updated:
password:
abstract:
---


右下角可以打开目录，或者Ctrl+F搜索
## 01.python不是内部或外部命令-配置环境变量
- 解决方案：
1 . 快捷键Win+R打开运行窗口
2 . 输入_where python_命令,可以看到python的安装位置，比如C:\python,复制
3 . 输入_set path=%path%;C:\python_后面的C:\pthon路径,粘贴
4 . 然后就可以开开心心的使用python命令啦
- 知根知底：
当要求系统运行一个程序而没有告诉它程序所在的完整路径时，系统除了在当前目录下面寻找此程序外，还会到 path 中指定的路径去找。用户通过设置环境变量，就可以在任何目录下运行添加了变量的程序。假如不添加环境变量，那么也可以进入到需要运行的程序目录下去执行命令。cmd切换目录使用_cd C:\xxx\xxx\xx_命令切换。

## 2.pip不是内部或外部命令-配置环境变量
- 解决方案：
同上

- 知根知底：

## 3.查找Python解释器所在位置
- 解决方案：

- 知根知底：
## 4.修改Python解释器的位置
- 解决方案：

- 知根知底：
## 9.体验课-查找URL
- 解决方案：

- 知根知底：
## 10.安装第三方模块PyInstaller
- 解决方案：

- 知根知底：
## 100.数据以JSON格式输出到文件
- 解决方案：

- 知根知底：
## 安装第三方模块lxml
- 解决方案：

- 知根知底：
## 12.Python中的小括号_中括号_花括号
- 解决方案：

- 知根知底：
## 13.chr()与ord()函数的作用
- 解决方案：

- 知根知底：
## 14.值的比较与id的比较
- 解决方案：

- 知根知底：
## 15.Python中格式化字符串的三种方式
- 解决方案：

- 知根知底：
## 16.Python中进制转换的函数
- 解决方案：

- 知根知底：
## 17.JSON格式转换错误-JSONDecodeError
- 解决方案：

- 知根知底：
## 18.Pycharm代码中波浪线问题的解决方案
- 解决方案：

- 知根知底：
## 19.缩进错误-IndentationError_unexpected indent
- 解决方案：

- 知根知底：
## 20.未定义错误-NameError-is not defined
- 解决方案：

- 知根知底：
## 21.语法错误-SyntaxError_invalid syntax
- 解决方案：

- 知根知底：
## 22.字典的无序性
- 解决方案：

- 知根知底：
## 23.安装第三方模块numpy
- 解决方案：

- 知根知底：
## 24.安装第三方模块pandas
- 解决方案：

- 知根知底：
## 25.Python解释器_IDLE_Pycharm
- 解决方案：

- 知根知底：
## 26.eval函数的作用
- 解决方案：

- 知根知底：
## 27.键错误-KeyError
- 解决方案：

- 知根知底：
## 28.类型错误-TypeError
- 解决方案：

- 知根知底：
## 29.lambda表达式
- 解决方案：

- 知根知底：
## 30.什么是保留字
- 解决方案：

- 知根知底：
## 31-体验课-伪装成浏览器填加请求头
- 解决方案：

- 知根知底：
## 32.安装第三方模块-pymysql
- 解决方案：

- 知根知底：
## 33.安装第三方模块-mysql-connector
- 解决方案：

- 知根知底：
## 34.如何在Pycharm中新建项目
- 解决方案：

- 知根知底：
## 35.进制转换
- 解决方案：

- 知根知底：
## 36.索引超出边界-IndexError
- 解决方案：

- 知根知底：
## 37.算术错误-ZeroDivisionError
- 解决方案：

- 知根知底：
## 38.标识符
- 解决方案：

- 知根知底：
## 39.随机数random
- 解决方案：

- 知根知底：
## 40.self与cls
- 解决方案：

- 知根知底：
41.递归算法
- 解决方案：

- 知根知底：
42.斐波那契数列
- 解决方案：

- 知根知底：
43.安装第三方模块xlrd
- 解决方案：

- 知根知底：
44.安装第三方模块xlwt
- 解决方案：

- 知根知底：
45.安装第三方模块easygui
46.安装第三方模块ipython
47.安装第三方模块jupyter
48.print()函数的源码分析
49.列表的切片操作
5.安装第三方模块requests
50.字符串的驻留机制
51.编译和解释
52.strptime()与strftime()的区别
53.续行符
54.文件未找到异常-FileNotFountError
55.json.load()与json.loads()
56.浮点数的不确定尾数问题
57.值相同的整数和浮点数哪个运算精度更高
58.Python中的局部变量和全局变量
59.Python中的绝对路径和相对路径
6.安装第三方模块removebg
60.谷歌浏览器安装Xpath插件
61.安装第三方模块selenium
## 62.Python中的isdigit()_isnumeric()_isdicimal()
## 63.Python中的目录和包
64.同一台机器上为不同版本的Python解释器安装模块
65.enumerate()与zip()
64.同一台机器上为不同版本的Python解释器安装模块
65.enumerate()与zip()
66.+与join()方法在字符串拼接时哪个更省时
67.Python中的空语句-pass语句
68.安装第三方模块pygame
69.安装第三方模块schedule
7.安装第三方模块python-docx
70.如何在Pycharm控制台输出彩色文字和背景
71.安装第三方模块prettytable
72.del_pop()_remove()_clear()
73.Python程序打包成.exe可执行程序
73.Python程序打包成.exe可执行程序.spec
74.字符串反转的三种方式
75.format格式化方法的控制
76.安装PyInstaller模块报错
77.Python中的=与==
78.显示结果保留两位小数
79.return的使用
8.安装第三方模块openpyxl
80.pycharm中的代码调试
81.New Environment与Existing Interpreter
82.Unicode码的转换
83.安装MongoDB数据库
84.removebg注册APIKey
85.安装Scrapy框架
86.Pycharm中设置Python文件的模板
87.Pycharm中设置字体大小
## 88.Pycharm设置窗体皮肤
## 89.seek方法的使用
## 90.range函数的详解
## 91.第三方库PIL的安装
## 92.第在方库的卸载
## 93.如何升级pip命令
## 94.修改控制台输出文字颜色
## 95.jupyter的使用
## 96.MySQL的安装
## 97.mysql不是内部或外部命令
## 98.Python中的浅拷贝
## 99.Python中的深拷贝            


<!--more-->
