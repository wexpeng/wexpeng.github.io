---
title: Linux光盘挂载
tags:
  - 技术
  - Linux
categories:
  - 经验
abbrlink: 9569
date: 2018-09-11 09:17:33
updated:
password:
abstract:
address:
---
实验系统：Centos6.5_x64

测试使用光盘挂载到`/media`，要保证`/media`目录要存在，光盘要插入;
光盘在Centos系统中设备名`sr0`，路径为`/dev/sr0`;
挂载后，无法弹出光驱，重启，或者卸载才能弹出光驱

直接挂载
```bash
#mount /dev/sr0 /media     //挂载
#umount /media             //卸载
```

<!--more-->
开机自动挂载

使用vim修改配置文件`/etc/fstab`
加入

```config
/dev/sr0      /mnt/cdrom         iso9600          defaults          0  0
```
文件格式要写对，后面的第一个个0代表不做dump检查，还可选1，2；（详情百度）
最后一个0代表不做fsck检查，一般来说，根目录设为1，其它要检测的设为2，自己信任的0，比如光盘

触发式挂载

这种方式只有当使用光驱时才会挂载，而且是自动的，挂载的目录无需自己建立。一段时间不占用这个挂载的文件夹就会自动卸载（umount），不占用系统资源！需要安装autofs服务，使用yum安装
（autofs服务）配置文件：
vim编辑 /etc/auto.master文件，加入：
```config
/media              /etc/auto.yum
```
#这句话的意思是，在`auto.yum`文件中配置
vim编辑/etc/auto.yum文件，( 在auto.master文件中定义的文件名），加入

```config
sr0            -fstype=iso9660        /dev/sr0
```
#这个会在media目录下自动生成一个sr0的目录作为挂载目录
既然是服务就需要启动

```bash
#etc/init.d/autofs start
#chkconfig sutofs on              // 开机自启
```
挂载远程资源

```bash
mount -o username=Administrator(everyone) //windowsIPaddress/共享名 /media
```
这样就可以把Windows电脑共享的目录挂载到Linux的/media目录下，非常方便
