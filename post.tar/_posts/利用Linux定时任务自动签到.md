---
title: 利用Linux定时任务自动签到
tags: Linux
categories: 经验
abbrlink: 18958
date: 2015-07-10 14:06:24
updated:
password:
abstract:
address:
---

利用unix系统中的crontab功能，几乎所有的unix-like都可以使用

首先要获取某个网站的签到网络请求，可以使用google浏览器自带的network功能捕获，拷贝curl链接，这个就是签到请求。

这里重点是抓包，测试结果要第二天才知道。复制的curl连接可以直接在Linux命令行输入，一般又多个网站的签到需求，建议创建一个crontab文件。

我们先看一下怎么把这行请求copy下来，以网易云音乐签到为例，这是图片演示：

![copy签到请求的步骤演示图](./images/签到步骤.png "步骤演示图")

<!--more-->

得到的粘贴版信息：
```bash
curl 'https://music.163.com/weapi/point/dailyTask?csrf_token=b7a1c698043d482560f0cce44ff63e53' -H 'Origin: https://music.163.com' -H 'Accept-Encoding: gzip, deflate, br' -H 'Accept-Language: zh-CN,zh;q=0.9' -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Accept: */*' -H 'Referer: https://music.163.com/discover' -H 'Cookie: _iuqxldmzr_=32; _ntes_nnid=747d80cace901d222900369b376b1a67,1532528882594; _ntes_nuid=747d80cace901d222900369b376b1a67; WM_TID=7wCxJdMQq1jsaKAHG9FO6Jv%2BpXC39FjR; __utmc=94650624; __utma=94650624.834439023.1532528883.1532689910.1532693185.12; __utmz=94650624.1532693185.12.12.utmcsr=localhost:4000|utmccn=(referral)|utmcmd=referral|utmcct=/%E3%80%8A%E8%A7%A6%E4%B8%8D%E5%8F%AF%E5%8F%8A%E3%80%8B%E8%A7%82%E5%90%8E%E6%84%9F/; JSESSIONID-WYYY=TfMiNorhJxoNNRHZzsT6I3ytA3SiEkrSMYckUktMqvzNh%2FW%2FMyuee7%2BTI41%2BnR07yCqVUeKxGQHZE%5CKYIguup6nFgRRXnf0drcWJ9Uri%2FTcz%5Cjpws90hcecjvJCJ%2FEkpQjn7UMxP%5CzMk%2BCG7O555SY%2FEV%5CQCrKnJUhRDlZqFTOO%2F%5CaBO%3A1532695189418; WM_NI=2GddNh7DkEcTCh%2BJTG0jODM96M%2F%2FfTEoqlmBokw3nWt6Ki1zAE%2FNJ9LMBR6cBT0GpUi0LZ1B11E9r%2F%2B6%2F5T0TWIzb2F8i95wbtz8wCldeR%2FrcR%2BpHRu8Xkuzm%2BEQKshAY0U%3D; WM_NIKE=9ca17ae2e6ffcda170e2e6ee9bca7dafbbb6b6d26b9a8d81b8c74dbc98abb3c566b2b7bbd9d2728a99a2b3c52af0fea7c3b92af299ac85cd64f59ca5a6e26081b8e5abd74df4b681a5d033f693e1d0e56087b1bf8df04aadb5b9d4ed5db8ea858ab472839be1afc93390938eb3b569828c00a8f35fabf084bbb44af3ef8bdaf125e9eae1d6d73c9889879be13a86e8a7dab87da2acb6d9f649b0bcabb3ae7aa18ee591cb5ab7e8988cf872aff58bb2ca79ac9f97d1d837e2a3; MUSIC_U=81b463b520d57cc36ade08b68cfeac96fccddbfe17f8e76c6e739cda4210db1da7a6212dc58f9f2b37673d28e13b757a8bafcdfe5ad2b092; __remember_me=true; __csrf=b7a1c698043d482560f0cce44ff63e53; __utmb=94650624.4.10.1532693185' -H 'Connection: keep-alive' --data 'params=IHpPHTtQNwhRrO2qJoTtSJYBcZ6tsV1YruVJ%2B9e0BLB4vAK9%2FUM38I3LTI2Jupe24DsIYDkSFhDEZZJiQdfoTiARxbRPNSuKMtMtvWSzKhXTrb78o9o0BlwoxOKiaD6L&encSecKey=5efc26c359444bea688cff13b45a64f413cb31312d012a82401b5c707e954777090e34e852626747a04f45755e8c1638b8b17dff9ac1121b437d571dba865b344f86b2459efa90b82c24d623fb52ba313d76d59ef361766b07103e32fa7ed96e4ed80f0a0de74a66b437a7f928b60d0481391cfa739c24011559caf738ad0b7c' --compressed
```

将来如果有高手看到了这行信息，大约可以直接登陆我的网易云账号了。是的，这里面包含登陆信息。

我们要建立一个`.sh`文件，把这行信息保存进去。注意查看行号是否只有一行。

```bash
# crontab -n   //输入后会出现一个vi输入框。
```

逻辑就是把所有的curl签到请求放在一个sh文件里面保存，再使用Linux的**定时任务**执行此sh文件。

如果有服务器的话，设定一天执行一次就好了，但是在自己用的电脑上，我设置的半小时一次，这样保险。因为不一定无时无刻开机嘛，执行此命令只需要消耗很少的资源。

我有很多网站在自动签到，包括签到领取下载币的，都有3000个币了。

手机上的也同样可以，以后再写。


>crontab 主要是在做计划任务、定时执行, 通常一般写法大概都是如下: 
```bash
30  23  *  *  * shutdown //每天晚上11点30关机  
```
规则如下: 

一共五颗`*`号 从左至右分别代表:**分 时 日 月 周**

取值范围如下表: 


|时间|允许的值得|
|---|---| 
|分钟|0-59| 
|小时|0-23| 
|日期|1-31|
|月份|1-12| 
|周|0-7|

**注意**：如果不在范围之内，程序是不会执行的


还有有这种写法:
```bash
@hourly /usr/local/www/awstats/cgi-bin/awstats.sh
```

>使用 @hourly 对应的是 0 \* \* \* \*, 下述可以使用

```bash
#前置字符           含义
------           ------- 
@reboot        	//每次开机执行 
@yearly         //一年执行一次,等同于 "0 0 1 1 *". 
@annually      	//和上面是一样的
@monthly       	//一个月执行一次, "0 0 1 * *". 
@weekly         //一周执行一次, "0 0 * * 0". 
@daily          //每天执行一次, "0 0 * * *". 
@midnight       //和上面是一样的 
@hourly         //每小时执行一次, "0 * * * *".
```

注意到，还有@reboot使用方式，所以写在 rc.local 的东西, 也可以使用 @reboot 写在 crontab 里面。

>re.local ：开机执行的东西

