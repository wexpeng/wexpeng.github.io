---
title: vim的基本配置
tags:
  - 技术
  - Linux
categories:
  - 经验
abbrlink: 8823
date: 2018-07-31 00:41:58
updated:
password:
abstract:
address:
---



昨天重装了系统，配置了许多细枝末节，终于到了vim。

## vim 基础操作
命令模式下常用命令：
### 移动光标
>`k\j\h\l`:与`上\下\左\右`功能键一一对应且兼容
`w`:上一个单词
`b`:下一个单词
`e`:单词尾部
`gg`:回到顶部
`G`:去文档最底部
`Ctrl+f`:上一页
`Ctrl+b`:下一页
`:130`:跳转到第130行
`0`:移动到行首
`$`:移动到行尾
`/word`：查找word的位置

<!--more-->

### 文字编辑
>`i`:在光标前插入
`a`:在光标后插入
`o`:在下一行插入
`r`:替换一个字符
`x`:删掉一个字符
`cw`:替换一个单词
`yy`:复制一行，（在前面输入数字，比如100yy，就是复制以下100行）
`dd`:删除一行，（同上）
`de`:删除一个单词
`p`:粘贴
`v`:选择范围，（使用y复制、x剪切、p粘贴,或者r替换）
`u`:撤销
`:r!date`:插入日期，`:r`是`:read`的缩写，！是表明要运行一个shell命令，意思是把shell命令的输出写到当前文档里面来，这样我们可以用`:r!cat otherfilename`把另一个文件传进来
`:w`:保存
`:q`:退出
`Ctrl+w q`:保存并退
`Ctrl+n`:自动补全，写代码非常好用，同时还有`Ctrl+p`

## vim 高级操作


### 查找替换
>`:s/old/new` :当前行的第一个old替换为new
`:s/old/new/g` :当前行的所有old替换为new
`:100,200s/old/new/g` :替换第100行到200行的old为new
`:%s/old/new/g` : 替换全文的old为new

**注意**全部没有空格

### 分屏
分屏最好用的地方在于多文件编辑，我们可以输入`:E`来打开一个窗口选择当前目录多文件。也可以直接用下面的命令打开一个文件。
>`:sp filename`:上下分屏(Ctrl+w s)
`:vsp filename`:左右分屏(Ctrl+w v) **提示**：可以多次分屏
`Ctrl+w k\j\h\l`:输入Ctrl+w后再输入上下左右即可切换编辑的文件,kjhl和上下左右键的功能一致
`Ctrl+w +`:增加高度
`Ctrl+w -`:减少高度
`Ctrl+w =`:恢复默认


### 文档加密
请百度，如果觉得对自己无用，请不要浪费时间。


### 自定义快捷键
查看下面的vim配置文件

## vim 配置文件
vim作为一款数十年口碑极好的编辑器，肯定有它得天独厚的东西，那就是功能完整，全盘自定义，甚至全部的界面。

此文件保存为`.vimrc`的纯文本文档放在用户根目录下。即可生效.
```vim
"显示行号
set number

"语法高亮
syntax on

"配色方案，方案可以在网上下载
"vim自己提供的在“/usr/share/vim/vim-least/colors”目录下
colorscheme monokai

"使用vim的键盘模式,即不兼容vi，我没有开启
"set nocompatible

"高亮当前行与列
set cursorline
"set cursorcolumn

"没有保存或文件只读时弹出确认
set confirm

"鼠标可用
set mouse=a

"文件自动检测外部更改
set autoread

"自动对齐
set autoindent

"智能缩进
set smartindent

"高亮查找匹配
set hlsearch

"显示匹配
set showmatch

"显示标尺，就是在右下角显示光标位置
set ruler

"不要闪烁
set novisualbell

"显示输入的命令
set showcmd

"tab缩进
set tabstop=4
set shiftwidth=4
set expandtab
set smarttab


"键盘映射

"连续输入‘//’，vim会执行‘0，i，#’三个键，即：在这一行最前面输入“#”
map // 0i#
imap // <ESC>0i#
vmap // <ESC>0i#

"F12快捷键，快速编译执行文件
map <F12> : call RunGcc()<CR>
imap <F12> <ESC>: call RunGcc()<CR>
vmap <F12> <ESC>: call RunGcc()<CR>
func! RunGcc()
    exec "w"
    if &filetype == "c"
        exec "!g++ % -o %<"
        exec "!./%<"
    elseif &filetype == "java"
        exec "!javac %"
        exec "!java %<"
    elseif &filetype == "python"
        exec "!python %"
    endif
endfunc
```

>后面的键盘映射可以看出，vim是一个可以编程的编译器。
这里不做详细解释，如有需要，可以留言或者联系我。




### vim 配色与高亮
vim自己提供的配色方案，均不太喜欢，所以使用sublime上的monokai配色方案。

方案文件：(保存为：`/usr/share/vim/vim-laest/colors/monikai.vim`)
```vim
" Vim color file
" Converted from Textmate theme Monokai using Coloration v0.3.2 (http://github.com/sickill/coloration)

set background=dark
highlight clear

if exists("syntax_on")
  syntax reset
endif

set t_Co=256
let g:colors_name = "monokai"

hi Cursor ctermfg=235 ctermbg=231 cterm=NONE guifg=#272822 guibg=#f8f8f0 gui=NONE
hi Visual ctermfg=NONE ctermbg=59 cterm=NONE guifg=NONE guibg=#49483e gui=NONE
hi CursorLine ctermfg=NONE ctermbg=237 cterm=NONE guifg=NONE guibg=#3c3d37 gui=NONE
hi CursorColumn ctermfg=NONE ctermbg=237 cterm=NONE guifg=NONE guibg=#3c3d37 gui=NONE
hi ColorColumn ctermfg=NONE ctermbg=237 cterm=NONE guifg=NONE guibg=#3c3d37 gui=NONE
hi LineNr ctermfg=102 ctermbg=237 cterm=NONE guifg=#90908a guibg=#3c3d37 gui=NONE
hi VertSplit ctermfg=241 ctermbg=241 cterm=NONE guifg=#64645e guibg=#64645e gui=NONE
hi MatchParen ctermfg=197 ctermbg=NONE cterm=underline guifg=#f92672 guibg=NONE gui=underline
hi StatusLine ctermfg=231 ctermbg=241 cterm=bold guifg=#f8f8f2 guibg=#64645e gui=bold
hi StatusLineNC ctermfg=231 ctermbg=241 cterm=NONE guifg=#f8f8f2 guibg=#64645e gui=NONE
hi Pmenu ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi PmenuSel ctermfg=NONE ctermbg=59 cterm=NONE guifg=NONE guibg=#49483e gui=NONE
hi IncSearch term=reverse cterm=reverse ctermfg=193 ctermbg=16 gui=reverse guifg=#C4BE89 guibg=#000000
hi Search term=reverse cterm=NONE ctermfg=231 ctermbg=24 gui=NONE guifg=#f8f8f2 guibg=#204a87
hi Directory ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi Folded ctermfg=242 ctermbg=235 cterm=NONE guifg=#75715e guibg=#272822 gui=NONE
hi SignColumn ctermfg=NONE ctermbg=237 cterm=NONE guifg=NONE guibg=#3c3d37 gui=NONE
hi Normal ctermfg=231 ctermbg=235 cterm=NONE guifg=#f8f8f2 guibg=#272822 gui=NONE
hi Boolean ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi Character ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi Comment ctermfg=242 ctermbg=NONE cterm=NONE guifg=#75715e guibg=NONE gui=NONE
hi Conditional ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi Constant ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi Define ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi DiffAdd ctermfg=231 ctermbg=64 cterm=bold guifg=#f8f8f2 guibg=#46830c gui=bold
hi DiffDelete ctermfg=88 ctermbg=NONE cterm=NONE guifg=#8b0807 guibg=NONE gui=NONE
hi DiffChange ctermfg=NONE ctermbg=NONE cterm=NONE guifg=#f8f8f2 guibg=#243955 gui=NONE
hi DiffText ctermfg=231 ctermbg=24 cterm=bold guifg=#f8f8f2 guibg=#204a87 gui=bold
hi ErrorMsg ctermfg=231 ctermbg=197 cterm=NONE guifg=#f8f8f0 guibg=#f92672 gui=NONE
hi WarningMsg ctermfg=231 ctermbg=197 cterm=NONE guifg=#f8f8f0 guibg=#f92672 gui=NONE
hi Float ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi Function ctermfg=148 ctermbg=NONE cterm=NONE guifg=#a6e22e guibg=NONE gui=NONE
hi Identifier ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=italic
hi Keyword ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi Label ctermfg=186 ctermbg=NONE cterm=NONE guifg=#e6db74 guibg=NONE gui=NONE
hi NonText ctermfg=59 ctermbg=236 cterm=NONE guifg=#49483e guibg=#31322c gui=NONE
hi Number ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi Operator ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi PreProc ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi Special ctermfg=231 ctermbg=NONE cterm=NONE guifg=#f8f8f2 guibg=NONE gui=NONE
hi SpecialComment ctermfg=242 ctermbg=NONE cterm=NONE guifg=#75715e guibg=NONE gui=NONE
hi SpecialKey ctermfg=59 ctermbg=237 cterm=NONE guifg=#49483e guibg=#3c3d37 gui=NONE
hi Statement ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi StorageClass ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=italic
hi String ctermfg=186 ctermbg=NONE cterm=NONE guifg=#e6db74 guibg=NONE gui=NONE
hi Tag ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi Title ctermfg=231 ctermbg=NONE cterm=bold guifg=#f8f8f2 guibg=NONE gui=bold
hi Todo ctermfg=95 ctermbg=NONE cterm=inverse,bold guifg=#75715e guibg=NONE gui=inverse,bold
hi Type ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi Underlined ctermfg=NONE ctermbg=NONE cterm=underline guifg=NONE guibg=NONE gui=underline
hi rubyClass ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi rubyFunction ctermfg=148 ctermbg=NONE cterm=NONE guifg=#a6e22e guibg=NONE gui=NONE
hi rubyInterpolationDelimiter ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi rubySymbol ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi rubyConstant ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=italic
hi rubyStringDelimiter ctermfg=186 ctermbg=NONE cterm=NONE guifg=#e6db74 guibg=NONE gui=NONE
hi rubyBlockParameter ctermfg=208 ctermbg=NONE cterm=NONE guifg=#fd971f guibg=NONE gui=italic
hi rubyInstanceVariable ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi rubyInclude ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi rubyGlobalVariable ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi rubyRegexp ctermfg=186 ctermbg=NONE cterm=NONE guifg=#e6db74 guibg=NONE gui=NONE
hi rubyRegexpDelimiter ctermfg=186 ctermbg=NONE cterm=NONE guifg=#e6db74 guibg=NONE gui=NONE
hi rubyEscape ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi rubyControl ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi rubyClassVariable ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi rubyOperator ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi rubyException ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi rubyPseudoVariable ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi rubyRailsUserClass ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=italic
hi rubyRailsARAssociationMethod ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=NONE
hi rubyRailsARMethod ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=NONE
hi rubyRailsRenderMethod ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=NONE
hi rubyRailsMethod ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=NONE
hi erubyDelimiter ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi erubyComment ctermfg=95 ctermbg=NONE cterm=NONE guifg=#75715e guibg=NONE gui=NONE
hi erubyRailsMethod ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=NONE
hi htmlTag ctermfg=148 ctermbg=NONE cterm=NONE guifg=#a6e22e guibg=NONE gui=NONE
hi htmlEndTag ctermfg=148 ctermbg=NONE cterm=NONE guifg=#a6e22e guibg=NONE gui=NONE
hi htmlTagName ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi htmlArg ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi htmlSpecialChar ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi javaScriptFunction ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=italic
hi javaScriptRailsFunction ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=NONE
hi javaScriptBraces ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi yamlKey ctermfg=197 ctermbg=NONE cterm=NONE guifg=#f92672 guibg=NONE gui=NONE
hi yamlAnchor ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi yamlAlias ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
hi yamlDocumentHeader ctermfg=186 ctermbg=NONE cterm=NONE guifg=#e6db74 guibg=NONE gui=NONE
hi cssURL ctermfg=208 ctermbg=NONE cterm=NONE guifg=#fd971f guibg=NONE gui=italic
hi cssFunctionName ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=NONE
hi cssColor ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi cssPseudoClassId ctermfg=148 ctermbg=NONE cterm=NONE guifg=#a6e22e guibg=NONE gui=NONE
hi cssClassName ctermfg=148 ctermbg=NONE cterm=NONE guifg=#a6e22e guibg=NONE gui=NONE
hi cssValueLength ctermfg=141 ctermbg=NONE cterm=NONE guifg=#ae81ff guibg=NONE gui=NONE
hi cssCommonAttr ctermfg=81 ctermbg=NONE cterm=NONE guifg=#66d9ef guibg=NONE gui=NONE
hi cssBraces ctermfg=NONE ctermbg=NONE cterm=NONE guifg=NONE guibg=NONE gui=NONE
```

### vim模版文件

模版文件有两种方式，一种文件型，一种配置型。文件型需要创建单独的模版文件，虽然配置方便功能强大，但不好管理。

比如在目录`/usr/share/vim/vimfiles/template`文件夹下建立一个template.html文件，在`~/.vimrc`中添加一行 
```vim
autocmd BufNewFile *.java r /usr/share/vim/vimfiles/template/tempalate.html
```
显而易见这句话的意思就是建立后缀为html的文件时，加载定义好的文件。

第二种是我使用的方式，直接在'.vimrc'文件中定义好要写入的模版

```vim
function AddFileInformation()

    if &filetype == "html"
        let template = "<!--@date".strftime( "%Y-%m-%d %H:%M" )."-->"."\n"
        \."<!doctype>"."\n"
        \."<html>"."\n"
        \."<head>"."\n"
        \."<title>".expand("%<")."</title>"."\n\n"
        \."</head>"."\n"
        \."<body>"."\n\n\n\n\n"
        \."</body"."\n"
        \."</html>"
    endif

    if &filetype == "java"
        let template = "//@date ".strftime( "%Y-%m-%d %H:%M")." \n"
        \."import java.util.io"."\n"
        \."public class ".expand("%<")."{"."\n"
        \."    public static void main( String args[] ){"."\n"
        \."    //codeing"."\n"
        \."    }"."\n"
        \."}"
    endif

    silent put! = template

endfunction


autocmd BufNewFile *.java call AddFileInformation()
autocmd BufNewFile *.html call AddFileInformation()
```


## 编辑器之争
常年在网络上有一群程序员为此争论，用vim还是IDE。

我有我的看法，如何让一个没有图形界面的人用IDE呢？这是可笑的，后来有人告诉我，做软件开发的不装图形界面不是没事找事吗？

比如说我现在写博客，我在windows台式机部署了一个环境，又在我的笔记本部署了，这边写了那边不同步。然后干脆在云服务器上写。之后，iPad都可以随时登录。体验非常好。


我并非一个vim资深用户，只是在没有IDE的时候用一下。这种感觉非常棒，而在我熟悉后，我并不想打开IDE来开发程序了，其实IDE是很智能的，各种繁琐细节都给你完整配置好了。而其实vim如果你肯花功夫的话，不会比一个IDE复杂。

就说这么多，这是个好东西。要善加利用。只是一晃眼都已经到了vim80了。网络上的资源鱼龙混杂，一群人抄来抄去，不说来源不讲理由，错了也不知道错了什么。我建议直接寻找vim的README文件一般会在`/usr/share/vim/vim-laest/doc/`文件下。

我的系统是macOS 11.13了，只有自己动手丰衣足食吧。

